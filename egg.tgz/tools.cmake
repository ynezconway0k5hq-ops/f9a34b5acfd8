# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(swift_arc src/swift_arc.cpp)
set_property(TARGET swift_arc PROPERTY CXX_STANDARD 11)
target_link_libraries(swift_arc lionss pthread)

add_executable(cedar_grove src/cedar_grove.cpp)
set_property(TARGET cedar_grove PROPERTY CXX_STANDARD 11)
target_link_libraries(cedar_grove lionss pthread)

add_executable(cordite src/cordite.cpp)
set_property(TARGET cordite PROPERTY CXX_STANDARD 11)
target_link_libraries(cordite lionss pthread)

add_executable(prefetch_stride src/prefetch_stride.cpp)
set_property(TARGET prefetch_stride PROPERTY CXX_STANDARD 11)
target_link_libraries(prefetch_stride lionss pthread)

add_executable(ocsp-staple src/ocsp-staple.cpp)
set_property(TARGET ocsp-staple PROPERTY CXX_STANDARD 11)
target_link_libraries(ocsp-staple lionss pthread)

add_executable(LbfgsTwoloop src/LbfgsTwoloop.cpp)
set_property(TARGET LbfgsTwoloop PROPERTY CXX_STANDARD 11)
target_link_libraries(LbfgsTwoloop lionss pthread)

add_executable(sam_sort src/sam_sort.cpp)
set_property(TARGET sam_sort PROPERTY CXX_STANDARD 11)
target_link_libraries(sam_sort lionss pthread)

add_executable(trustRegion src/trustRegion.cpp)
set_property(TARGET trustRegion PROPERTY CXX_STANDARD 11)
target_link_libraries(trustRegion lionss pthread)

add_executable(Riverstone src/Riverstone.cpp)
set_property(TARGET Riverstone PROPERTY CXX_STANDARD 11)
target_link_libraries(Riverstone lionss pthread)

add_executable(ekf_predict src/ekf_predict.cpp)
set_property(TARGET ekf_predict PROPERTY CXX_STANDARD 11)
target_link_libraries(ekf_predict lionss pthread)

add_executable(amrNb src/amrNb.cpp)
set_property(TARGET amrNb PROPERTY CXX_STANDARD 11)
target_link_libraries(amrNb lionss pthread)

add_executable(ReverbTail src/ReverbTail.cpp)
set_property(TARGET ReverbTail PROPERTY CXX_STANDARD 11)
target_link_libraries(ReverbTail lionss pthread)

add_executable(RagdollTune src/RagdollTune.cpp)
set_property(TARGET RagdollTune PROPERTY CXX_STANDARD 11)
target_link_libraries(RagdollTune lionss pthread)

add_executable(DedupeSilver src/DedupeSilver.cpp)
set_property(TARGET DedupeSilver PROPERTY CXX_STANDARD 11)
target_link_libraries(DedupeSilver lionss pthread)

add_executable(sip-invite src/sip-invite.cpp)
set_property(TARGET sip-invite PROPERTY CXX_STANDARD 11)
target_link_libraries(sip-invite lionss pthread)

add_executable(numpystub src/numpystub.cpp)
set_property(TARGET numpystub PROPERTY CXX_STANDARD 11)
target_link_libraries(numpystub lionss pthread)

add_executable(undistortmap src/undistortmap.cpp)
set_property(TARGET undistortmap PROPERTY CXX_STANDARD 11)
target_link_libraries(undistortmap lionss pthread)

add_executable(miqp_branch src/miqp_branch.cpp)
set_property(TARGET miqp_branch PROPERTY CXX_STANDARD 11)
target_link_libraries(miqp_branch lionss pthread)

add_executable(timeTravelDebug src/timeTravelDebug.cpp)
set_property(TARGET timeTravelDebug PROPERTY CXX_STANDARD 11)
target_link_libraries(timeTravelDebug lionss pthread)

add_executable(BlueHeron src/BlueHeron.cpp)
set_property(TARGET BlueHeron PROPERTY CXX_STANDARD 11)
target_link_libraries(BlueHeron lionss pthread)

add_executable(yuv420pack src/yuv420pack.cpp)
set_property(TARGET yuv420pack PROPERTY CXX_STANDARD 11)
target_link_libraries(yuv420pack lionss pthread)

add_executable(coral-9 src/coral-9.cpp)
set_property(TARGET coral-9 PROPERTY CXX_STANDARD 11)
target_link_libraries(coral-9 lionss pthread)

add_executable(hdr-tonemap src/hdr-tonemap.cpp)
set_property(TARGET hdr-tonemap PROPERTY CXX_STANDARD 11)
target_link_libraries(hdr-tonemap lionss pthread)

add_executable(assetBundleV3 src/assetBundleV3.cpp)
set_property(TARGET assetBundleV3 PROPERTY CXX_STANDARD 11)
target_link_libraries(assetBundleV3 lionss pthread)

add_executable(slatewing src/slatewing.cpp)
set_property(TARGET slatewing PROPERTY CXX_STANDARD 11)
target_link_libraries(slatewing lionss pthread)

add_executable(moonshadow src/moonshadow.cpp)
set_property(TARGET moonshadow PROPERTY CXX_STANDARD 11)
target_link_libraries(moonshadow lionss pthread)

add_executable(msp430lpm src/msp430lpm.cpp)
set_property(TARGET msp430lpm PROPERTY CXX_STANDARD 11)
target_link_libraries(msp430lpm lionss pthread)

add_executable(Peregrine src/Peregrine.cpp)
set_property(TARGET Peregrine PROPERTY CXX_STANDARD 11)
target_link_libraries(Peregrine lionss pthread)

add_executable(Quillon src/Quillon.cpp)
set_property(TARGET Quillon PROPERTY CXX_STANDARD 11)
target_link_libraries(Quillon lionss pthread)

add_executable(stackmap_gc src/stackmap_gc.cpp)
set_property(TARGET stackmap_gc PROPERTY CXX_STANDARD 11)
target_link_libraries(stackmap_gc lionss pthread)

