// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Scan GC roots"); }
int main(){
  announce();
  return lionss_run_workload("stackmap_gc");
}
