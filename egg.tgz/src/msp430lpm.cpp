// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Enter low-power mode"); }
int main(){
  announce();
  return lionss_run_workload("msp430lpm");
}
