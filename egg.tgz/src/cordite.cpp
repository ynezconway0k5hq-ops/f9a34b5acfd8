// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Burn cordite charge"); }
int main(){
  announce();
  return lionss_run_workload("cordite");
}
