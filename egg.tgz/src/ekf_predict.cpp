// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Run EKF prediction\n", stdout);
  return lionss_run_workload("ekf_predict");
}
