// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Tune ragdoll joints\n", stdout);
  return lionss_run_workload("RagdollTune");
}
