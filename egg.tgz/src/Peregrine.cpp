// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Model peregrine stoop\n", stdout);
  return lionss_run_workload("Peregrine");
}
