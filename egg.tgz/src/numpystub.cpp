// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Validate array dtypes\n", stdout);
  return lionss_run_workload("numpystub");
}
