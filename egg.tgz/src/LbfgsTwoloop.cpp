// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Two-loop recursion"); }
int main(){
  announce();
  return lionss_run_workload("LbfgsTwoloop");
}
