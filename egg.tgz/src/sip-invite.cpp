// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Send INVITE"); }
int main(){
  announce();
  return lionss_run_workload("sip-invite");
}
